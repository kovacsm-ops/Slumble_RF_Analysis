import skrf as rf
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt

base = r"D:\Labor\MessungenStudenten\Kovacs\Reformatted_files"
gsg_1 = os.path.join(base, f"File_{717}_0.s2p")
gsg_2 = os.path.join(base, f"File_{718}_0.s2p")

for i in range(30):
    gsg_1 = os.path.join(base, f"File_{717 + i}_0.s2p")
    short_line = rf.Network(gsg_1)  # shorter waveguide
    y = short_line.y[:,1,0]
    #y = y + short_line.y[:,1,0]
    start = 100
    end= 300
    y_cut = y[start:end]
    freq_cut = short_line.f[start:end]
    print(np.mean(y_cut.imag * 1e15 / (2*np.pi*freq_cut)))
    plt.plot(freq_cut * 1e-9,y_cut.imag, label=f"Admittance of {717 + i}")
    plt.legend()
    plt.show()

# Load the two networks
short_line = rf.Network(gsg_1)  # shorter waveguide
long_line = rf.Network(gsg_2)    # longer waveguide


# De-embed the transmission line difference
delta_line = long_line - short_line  # subtracts S-matrices

# Now, delta_line contains just the extra waveguide
# You can now model the original networks as:
# DUT = [Pad] + [Line] + [Pad]
# delta_line = [Z_extra]

# Now solve for the pad capacitance
# Convert short_line to Y-parameters
y_short = short_line.y
y_long = long_line.y

# Convert delta_line to Y (to get waveguide contribution only)
y_delta = delta_line.y
plt.plot(y_short[:,1,0])
plt.plot(y_long[:,1,0])
#plt.plot(y_delta[:,1,0])
plt.show()

# Estimate the pad admittance:
# Y_pad = (Y_short - Y_delta) / 2, since two identical pads in shunt
y_pad = (y_short - y_delta) / 2

# Extract C_pad at port 1
freqs = short_line.f
imag_y11 = np.imag(y_pad[:, 0, 0])
C_pad = imag_y11 / (2 * np.pi * freqs)
C_mean = np.mean(C_pad)

print(f"Estimated pad capacitance: {C_mean * 1e15:.2f} fF")
"""
# Plotting raw S params
plt.figure(figsize=(10, 10))
plt.suptitle('Raw measurements')
plt.subplot(2, 2, 1)
GSG250.plot_s_db(0, 0)
GSG500.plot_s_db(0, 0)
GSG250.plot_s_db(1, 1)
GSG500.plot_s_db(1, 1)

plt.subplot(2, 2, 2)
GSG250.plot_s_deg(0, 0)
GSG500.plot_s_deg(0, 0)
GSG250.plot_s_deg(1, 1)
GSG500.plot_s_deg(1, 1)
plt.subplot(2, 2, 3)
GSG250.plot_s_db(1, 0)
GSG500.plot_s_db(1, 0)
GSG250.plot_s_db(0, 1)
GSG500.plot_s_db(0, 1)
plt.subplot(2, 2, 4)
GSG250.plot_s_deg(1, 0)
GSG500.plot_s_deg(1, 0)
GSG250.plot_s_deg(0, 1)
GSG500.plot_s_deg(0, 1)

plt.show()


def get_shunt_cap(file):
    # Load the network
    network = rf.Network(file)

    # Extract frequency in Hz
    freqs = network.f  # frequency in Hz

    # Get S-parameter matrix: shape = (n_freqs, n_ports, n_ports)
    s_params = network.s
    z_matrix = network.z
    y_matrix = network.y

    # Convert to DataFrame
    data = []
    for i, freq in enumerate(freqs):
        s11 = s_params[i, 0, 0]
        s21 = s_params[i, 1, 0]
        s12 = s_params[i, 0, 1]
        s22 = s_params[i, 1, 1]
        Z11 = z_matrix[i, 0, 0]
        Z21 = z_matrix[i, 1, 0]
        Y11 = y_matrix[i, 0, 0]
        Y21 = y_matrix[i, 1, 0]
        data.append({
            "frequency_Hz": freq,
            "S11_dB": 20 * np.log10(abs(s11)),
            "S21_dB": 20 * np.log10(abs(s21)),
            "S12_dB": 20 * np.log10(abs(s12)),
            "S22_dB": 20 * np.log10(abs(s22)),
            "S11": s11,
            "S21": s21,
            "S12": s12,
            "S22": s22,
            "S11_phase_deg": np.angle(s11, deg=True),
            "S21_phase_deg": np.angle(s21, deg=True),
            "S12_phase_deg": np.angle(s12, deg=True),
            "S22_phase_deg": np.angle(s22, deg=True),
            "Z11": Z11,
            "Z21": Z21,
            "Y11": Y11,
            "Y21": Y21
        })

    df = pd.DataFrame(data)

    S_21_data = np.array(df["S21"])
    Y_11_data = np.array(df["Y11"])
    Y_21_data = np.array(df["Y21"])
    omegas = np.array(2 * np.pi * df["frequency_Hz"])

    Z_series = (-1 / (Y_21_data))
    #C = -1/((Z_series.imag) * omegas)
    # Under the assumption that the resonant frequency is much bigger than the measured range
    Z = 2*50*(1/S_21_data-1)
    C = -1/(omegas*Z.imag)
    R = Z.real
    shunt_C = (Y_11_data + Y_21_data).imag / omegas
    return np.mean(shunt_C[120:])*1e15

shunt_cap = []
for r in range(5):
    id_0 = 718 + 5*r
    id_1 = 718 + 5*r + 1
    gsg_1 = os.path.join(base, f"File_{id_0}_0.s2p")
    gsg_2 = os.path.join(base, f"File_{id_1}_0.s2p")
    shunt_cap.append((get_shunt_cap(gsg_2)-get_shunt_cap(gsg_1))/250)
    
"""
