import numpy as np

mu_0 = 1.25e-6
n = 3 # Number of turns
w = 2e-6
s = 6e-6
#s/w must be small
b = (s+w)/(2*np.pi)
d_in = 20e-6
d_out = 2*2*np.pi*n*b + d_in

# Current Sheet formula
c_1 = 1.0
c_2 = 2.46
c_3 = 0
c_4 = 0.2

d_avg = (d_in + d_out)/2

ro = (d_out-d_in)/(d_out + d_in)

def current_sheet(d_avg,n,ro):
    return 1e9*(c_1*mu_0*d_avg*n**2)*(np.log(c_2/ro) + c_3*ro*c_4*ro**2)/2

print(current_sheet(d_avg,n,ro))
