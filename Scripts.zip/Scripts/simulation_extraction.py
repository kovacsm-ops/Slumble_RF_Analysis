import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from extract_params import *
from scipy.interpolate import interp1d

def s_to_y(S11, S21, Z0=50):
    S = np.array([
        [S11, S21],
        [S21, S11]
    ], dtype=complex)
    I = np.identity(2, dtype=complex)
    Y = (1 / Z0) * np.matmul(I - S, np.linalg.inv(I + S))
    return Y[0][0], Y[0][1]


def extract_params(full_data_set):

    frequencies = (full_data_set['freq'] * 1e9).to_numpy()
    omegas = np.array(2 * np.pi * frequencies)
    S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
    S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()

    y_11_data = []
    y_21_data = []
    for index, s_param in enumerate(S_11_data):
        y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
        y_11_data.append(y_11)
        y_21_data.append(y_21)
    y_11_data = np.array(y_11_data)
    y_21_data = np.array(y_21_data)
    Z_series = -1/y_21_data
    y_shunt = y_11_data + y_21_data
    real_parts = Z_series.real
    imag_parts = Z_series.imag
    M = construct_M_matrix(2, 0, omegas, real_parts, imag_parts)
    C = construct_C_vector(2, 0, omegas, real_parts, imag_parts)
    N = np.linalg.inv(M) @ C
    print(N)
    R = N[0]
    L = N[1]
    plt.plot(S_21_data.imag)
    plt.show()

    # Under the assumption that the measured frequency range is far from SRF
    #Z = 2 * 50 * (1 / S_21_data - 1)
    #L = Z.imag / omegas
    #R = 2 * 50 * (S_21_data.real / np.abs(S_21_data) ** 2 - 1)
    shunt_C = (y_11_data + y_21_data).imag / omegas
    plt.plot(L*omegas)
    plt.plot(imag_parts)
    plt.show()
    print(R,L,np.mean(shunt_C))

def extract_params_from_sweep_n(full_data_set):
    sweep_param = "n"
    sweep_params = full_data_set[sweep_param].unique()
    L = []
    C = []
    R = []
    inductance_arrays = []
    SRF = []
    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]
        y_11_data = []
        y_21_data = []

        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)
        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        omegas = 2 * np.pi * frequencies_filtered
        r,l,c, inductances_array = extract_spiral_inductor_params(S_21_data,y_11_data, y_21_data, omegas)
        L.append(l)
        C.append(c)
        inductance_arrays.append(inductances_array)
        end_freq = np.argmax((-1 / y_21_data).imag)
        SRF.append(frequencies_filtered[end_freq])
        R.append(r)
    L = np.array(L)
    C = np.array(C)
    R = np.array(R)


    #fig, axs = plt.subplots(1, 2, figsize=(15, 5))
    return np. array(frequencies_filtered),np.array(inductance_arrays), SRF, C, R

def extract_params_from_sweep_trace(full_data_set):
    sweep_param = "thickness"
    sweep_params = full_data_set[sweep_param].unique()
    SRF = []
    L = []
    C = []
    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]
        y_11_data = []
        y_21_data = []

        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)
        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        Z_series = -1 / y_21_data
        #peaks, _ = find_peaks(abs(Z_series.imag))
        #f_0 = frequencies_filtered[peaks[0]]
        #SRF.append(f_0)
        #print(f_0, frequencies_filtered[70])
        frequencies_filtered = frequencies_filtered[:41]
        y_11_data = y_11_data[:41]
        y_21_data = y_21_data[:41]

        Z_series = -1 / y_21_data
        y_shunt = y_11_data + y_21_data
        real_parts = Z_series.real
        imag_parts = Z_series.imag
        omegas = 2 * np.pi * frequencies_filtered
        r,l,c = extract_spiral_inductor_params(S_21_data,y_11_data, y_21_data, omegas)
        L.append(l)
        C.append(c)
    L = np.array(L)
    C = np.array(C)
    #SRF = np.array(SRF)


    fig, axs = plt.subplots(1, 2, figsize=(15, 5))

    axs[0].plot(sweep_params, L*1e9, "g*")
    axs[0].set_title("Inductance Tendency")
    axs[0].set_xlabel("Trace thickness [um]")
    axs[0].set_ylabel("Inductance [nH]")

    axs[1].plot(sweep_params, C*1e15, "b*")
    axs[1].set_title("Parasitic Capacitance Tendency")
    axs[1].set_xlabel("Trace thickness [um]")
    axs[1].set_ylabel("Capacitance [fF]")

    plt.show()
def extract_params_from_sweep_gap(full_data_set):
    sweep_param = "gap_size"
    sweep_params = full_data_set[sweep_param].unique()
    SRF = []
    R = []
    L = []
    C = []
    C_shunt = []
    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]
        y_11_data = []
        y_21_data = []

        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)

        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        omegas = 2 * np.pi * frequencies_filtered
        Z_series = -1 / y_21_data
        peaks, _ = find_peaks(abs(Z_series.imag))
        f_0 = frequencies_filtered[peaks[0]]
        SRF.append(f_0)

        r,l,c_shunt = extract_spiral_inductor_params(S_21_data,y_11_data, y_21_data, omegas)

        c_par = 1/(l*(2*np.pi*f_0)**2)
        R.append(r)
        L.append(l)
        C.append(c_par)
        C_shunt.append(c_shunt)

    R = np.array(R)
    L = np.array(L)
    C = np.array(C)
    C_shunt = np.array(C_shunt)
    SRF = np.array(SRF)

    fig, axs = plt.subplots(1, 5, figsize=(20, 5))

    axs[0].plot(sweep_params, L*1e9, "r*")
    axs[0].set_title("Inductance Tendency")
    axs[0].set_xlabel("Gap distance [um]")
    axs[0].set_ylabel("Inductance [nH]")

    axs[1].plot(sweep_params, C*1e15, "g*")
    axs[1].set_title("Parasitic Capacitance Tendency")
    axs[1].set_xlabel("Gap distance [um]")
    axs[1].set_ylabel("Capacitance [fF]")

    axs[2].plot(sweep_params, C_shunt * 1e15, "b*")
    axs[2].set_title("Shunt Capacitance Tendency")
    axs[2].set_xlabel("Gap distance [um]")
    axs[2].set_ylabel("Capacitance [fF]")

    axs[3].plot(sweep_params, SRF*1e-9, "y*")
    axs[3].set_title("Self Resonant Frequency Tendency")
    axs[3].set_xlabel("Gap distance [um]")
    axs[3].set_ylabel("SRF [GHz]")

    axs[4].plot(sweep_params, R , "m*")
    axs[4].set_title("Resistance Tendency")
    axs[4].set_xlabel("Gap distance [um]")
    axs[4].set_ylabel("Resistance [Ohms]")
    plt.show()

def extract_spiral_inductor_params(S_21_data,Y_11_data,Y_21_data, omegas):

    # Under the assumption that the measured frequency range is far from SRF
    Z = 2 * 50 * (1 / S_21_data - 1)
    L = np.mean(Z.imag / omegas)
    inductances = Z.imag / omegas
    # R = 2*50*(S_21_data.real/np.abs(S_21_data)**2-1)
    R = np.mean(Z.real)
    shunt_C = (Y_11_data + Y_21_data).imag / omegas
    return R, L, np.mean(shunt_C), inductances

def extract_capacitor_from_sweep_length(full_data_set):
    sweep_param = "cap_height"
    sweep_params = full_data_set[sweep_param].unique()
    SRF = []
    L = []
    C = []
    R = []
    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]
        y_11_data = []
        y_21_data = []

        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)
        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        omegas = 2 * np.pi * frequencies_filtered
        indeces = np.where((1/y_21_data).imag <= 0)[0]
        SRF.append(frequencies_filtered[indeces[0]])
        print(frequencies_filtered[indeces[0]])
        plt.plot((1/y_21_data).imag)
        plt.show()
        r,c,c_shunt = extract_capacitor_params(S_21_data[:6],y_11_data[:6], y_21_data[:6], omegas[:6])
        C.append(c)

    C = np.array(C)
    SRF = np.array(SRF)
    # [2.47843406e-13,4.73338608e-13,6.95867574e-13,9.10042445e-13,1.13465230e-12]
    fig, axs = plt.subplots(1, 2, figsize=(15, 5))

    axs[0].plot(sweep_params, C*1e12, "g*")
    axs[0].set_title("Capacitance Tendency")
    axs[0].set_xlabel("Length [um]")
    axs[0].set_ylabel("Capacitance [pF]")

    axs[1].plot(sweep_params, SRF * 1e-9, "g*")
    axs[1].set_title("SRF")
    axs[1].set_xlabel("Length [um]")
    axs[1].set_ylabel("SRF [GHz]")

    plt.show()

def extract_capacitor_params(S_21_data,Y_11_data,Y_21_data, omegas):
    # C = -1/((Z_series.imag) * omegas)
    # Under the assumption that the resonant frequency is much bigger than the measured range
    Z = 2 * 50 * (1 / S_21_data - 1)
    C = -1 / (omegas * Z.imag)
    R = Z.real
    shunt_C = (Y_11_data + Y_21_data).imag / omegas
    return np.mean(R), np.mean(C),np.mean(shunt_C)

"""

data_path = r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\Important Data\Realistic_simulation_turns_sweep_4um_trace_thickness_real_hight_SRF.csv"
df = pd.read_csv(data_path)
frequencies, L_simulated, srf = extract_params_from_sweep_n(df)

for id, L in enumerate(L_simulated):
    print(srf[id] * 1e-9)
    plt.plot(frequencies, L)
    plt.show()

"""
data_path = r"D:\Studenten\Kovacs_Marton\privat\Capacitor Design\Capacitor_sweep.csv"
df = pd.read_csv(data_path)
extract_capacitor_from_sweep_length(df)

data_path = r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\Important Data\Realistic_simulation_turns_sweep_1um_trace_thickness.csv"
df = pd.read_csv(data_path)
f, L , SRF, C, R  = extract_params_from_sweep_n(df)
L = np.array([np.mean(i) for i in L])
C = np.array([np.mean(i) for i in C])
R = np.array([np.mean(i) for i in R])
SRF = np.array([np.mean(i) for i in SRF])
n = [1,2,3,4]

plt.plot([1,2,3,4],SRF, "*", label="Trace Width 1um, 6um gap")
plt.legend()
plt.xlabel("Number of turns")
plt.ylabel("Inductance [nH]")
plt.grid(True)
plt.xticks(n)
plt.show()

plt.plot([1,2,3,4],L * 1e9, "*", label="Trace Width 2um, 6um gap")
plt.legend()
plt.xlabel("Number of turns")
plt.ylabel("Inductance [nH]")
plt.grid(True)
plt.xticks(n)
plt.show()

plt.plot([1,2,3,4],C * 1e15, "*", label="Trace Width 2um, 6um gap")
plt.xlabel("Number of turns")
plt.ylabel("Capacitance [fC]")
plt.legend()
plt.xticks(n)
plt.grid(True)
plt.show()

plt.plot([1,2,3,4],R , "*", label="Trace Width 2um, 6um gap")
plt.xlabel("Number of turns")
plt.ylabel("Resistance [Ohms]")
plt.legend()
plt.xticks(n)
plt.grid(True)
plt.show()
#data_path = r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\Important Data\Realistic_simulation_turns_sweep_4um_trace_thickness.csv"
#df = pd.read_csv(data_path)
#print(extract_params_from_sweep_n(df))






