"""
This script is used for extracting Self Resonant Frequencies from simulation data of Comsol.
Specifically, over the sweep parameter number of turns (n), can be adjusted to any other sweep param.
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


def s_to_y(S11, S21, Z0=50):
    S = np.array([
        [S11, S21],
        [S21, S11]
    ], dtype=complex)
    I = np.identity(2, dtype=complex)
    Y = (1 / Z0) * np.matmul(I - S, np.linalg.inv(I + S))
    return Y[0][0], Y[0][1]


def get_SRF(path):
    full_data_set = pd.read_csv(path)
    sweep_param = "n"
    sweep_params = full_data_set[sweep_param].unique()
    SRF = []

    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]
        y_11_data = []
        y_21_data = []

        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)
        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        omegas = 2 * np.pi * frequencies_filtered
        end_freq = np.argmax((-1 / y_21_data).imag)
        SRF.append(frequencies_filtered[end_freq])
    return SRF

SRF_2um = get_SRF(r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\Important Data\Realistic_simulation_turns_sweep_2um_trace_thickness_SRF.csv")
SRF_2um = np.array(SRF_2um) * 1e-9
print(SRF_2um[:4])
meas_SRF = [64.32, 64.32, 54.4, 35.72]
plt.plot([1,2,3,4],SRF_2um[:4], "r*", label = "Simualated 2um trace thickness")
plt.plot([1,2,3,4],meas_SRF, "o", label="Measured 2um trace thickness")

SRF_4um = get_SRF(r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\Important Data\Realistic_simulation_turns_sweep_4um_trace_thickness_real_hight_SRF.csv")
SRF_4um = np.array(SRF_4um) * 1e-9
meas_SRF = [64.32, 60.234, 38.395, 25.66]
plt.plot([1,2,3,4],SRF_4um, "*", label = "Simualated 4um trace thickness")
plt.plot([1,2,3,4],meas_SRF, "o", label="Measured 4um trace thickness")
plt.title("Self Resonant Frequency")
plt.grid(True)
plt.xticks([1,2,3,4])
plt.xlabel("Number of turns")
plt.ylabel("[GHz]")
plt.legend()
plt.show()
