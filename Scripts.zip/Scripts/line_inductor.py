import numpy as np
import os
import skrf as rf
import pandas as pd
import matplotlib.pyplot as plt

def resistance_of_inductor(length,width,height):
    return 2.44e-8*length/(width*height)
base = r"C:\Users\Marci\Documents\ETH\Spring 2025\Bachelor Thesis\Lab Measurements\2025-05-22_S-Para-Measurements"
gsg_1 = os.path.join(base, f"File_{16}.s2p")
gsg_2 = os.path.join(base, f"File_{17}.s2p")

GSG250 = rf.Network(gsg_1)
GSG250.name = "100 um GSG Line"
GSG500 = rf.Network(gsg_2)
GSG500.name = "200 um GSG Line"

print(f"Resistance of 100 um line: {resistance_of_inductor(100e-6, 1e-6,0.1e-6)}")
print(f"Resistance of 200 um line: {resistance_of_inductor(200e-6, 1e-6,0.1e-6)}")

Y = GSG250.y  # shape: (n_freqs, 2, 2)
S = GSG250.s  # shape: (n_freqs, 2, 2)
A = rf.network.s2a(S,50)
freqs = GSG250.f  # in Hz
omega = 2 * np.pi * freqs
# Find 2GHz
start_index = 0
while freqs[start_index] < 2e9:
    start_index += 1

Y21 = Y[:, 1, 0]
Y11 = Y[:, 0, 0]
S21 = S[:,1,0]
B = A[:,1,0]


# Plotting raw S params
plt.figure(figsize=(10, 10))
plt.suptitle('Raw measurements')
plt.subplot(2, 2, 1)
GSG250.plot_s_db(0, 0)
GSG500.plot_s_db(0, 0)
GSG250.plot_s_db(1, 1)
GSG500.plot_s_db(1, 1)

plt.subplot(2, 2, 2)
GSG250.plot_s_deg(0, 0)
GSG500.plot_s_deg(0, 0)
GSG250.plot_s_deg(1, 1)
GSG500.plot_s_deg(1, 1)
plt.subplot(2, 2, 3)
"""
GSG250.plot_s_db(1, 0)
GSG500.plot_s_db(1, 0)
GSG250.plot_s_db(0, 1)
GSG500.plot_s_db(0, 1)
"""
plt.subplot(2, 2, 4)
GSG250.plot_s_deg(1, 0)
GSG500.plot_s_deg(1, 0)
GSG250.plot_s_deg(0, 1)
GSG500.plot_s_deg(0, 1)

plt.show()
