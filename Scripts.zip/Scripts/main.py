import os
from extract_params import *
from batches.batch import Batch


# Example usage:
if __name__ == "__main__":
    #base_dir = r"D:\Labor\MessungenStudenten\Kovacs\Processed_files"
    #base_dir = r"D:\Studenten\Kovacs_Marton\oeffentlich\67GHz measurements\de_embedded"
    base_dir = r"D:\Labor\MessungenStudenten\Kovacs\Reformatted_files"
    #base_dir = r"C:\Users\Marci\Documents\ETH\Spring 2025\Bachelor Thesis\Lab Measurements\2025-05-22_S-Para-Measurements"
    # Using data above 2 GHz index 45

    """
    spiral_inductor_ids = [i for i in range(16,36)]
    #spiral_inductor_ids = [18, 23,28,33]
    spiral_inductor_batch = Batch(spiral_inductor_ids,base_dir, "Spiral_Inductor")
    spiral_inductor_batch.process_units()
    spiral_inductor_batch.plot_batch()
    
    
    line_inductor_ids = [i for i in range(0, 16)]
    line_inductor_batch = Batch(line_inductor_ids, base_dir, "Line_Inductors")
    line_inductor_batch.process_units()
    line_inductor_batch.plot_batch()
    """
    plate_capacitor_ids = [i for i in range(36, 56)]
    plate_capacitor_batch = Batch(plate_capacitor_ids, base_dir, "Plate_Capacitors")
    plate_capacitor_batch.process_units()
    plate_capacitor_batch.plot_batch()


