import numpy as np
import os
import skrf as rf
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter
sim_path = r"D:\Studenten\Kovacs_Marton\privat\Capacitor Design\Plate_Capacitor_Sweep_all_units.csv"
from batches.unit import Plate_Capacitor
from batches.batch import Batch
import os
import pandas as pd

# Function to fill data from dictionary
def fill_data(data_dict, x, y):
    data = np.zeros((len(y), len(x)))  # rows = y, cols = x
    for i, x_unit in enumerate(x):
        for j, y_unit in enumerate(y):
            key = (x_unit, y_unit)
            data[j][i] = data_dict.get(key, 0)
    return np.round(data, 4)


def s_to_y(S11, S21, Z0=50):
    S = np.array([
        [S11, S21],
        [S21, S11]
    ], dtype=complex)
    I = np.identity(2, dtype=complex)
    Y = (1 / Z0) * np.matmul(I - S, np.linalg.inv(I + S))
    return Y[0][0], Y[0][1]


def process_all_plate_caps(csv_path):
    df = pd.read_csv(csv_path)

    widths = df['signal_width'].unique()
    lengths = df['cap_height'].unique()

    widths = sorted(widths)
    lengths = sorted(lengths)

    processed_units = []
    id_counter = 36  # match your ID logic in Plate_Capacitor

    for width in widths:
        for length in lengths:
            subset = df[(df['signal_width'] == width) & (df['cap_height'] == length)]
            if subset.empty:
                continue

            # Sort by frequency if needed
            subset = subset.sort_values(by="freq")

            # Create Plate_Capacitor
            cap = Plate_Capacitor(id_counter)
            id_counter += 1

            freq = np.array(subset["freq"]) * 1e9
            omegas = 2 * np.pi * freq
            S_11_data = subset["S11"].str.replace('i', 'j').astype(complex).to_numpy()
            S_21_data = subset["S21"].str.replace('i', 'j').astype(complex).to_numpy()
            y_11_data = []
            y_21_data = []

            for index, s_param in enumerate(S_11_data):
                y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
                y_11_data.append(y_11)
                y_21_data.append(y_21)

            y_11_data = np.array(y_11_data)
            y_21_data = np.array(y_21_data)

            Z = -1 / y_21_data
            valid_indices = np.where(Z.imag >= 0)[0]
            SRF = freq[valid_indices[0]] if valid_indices.size > 0 else 0

            f_start, f_end = 0, -1
            #plt.plot(freq[f_start:f_end],Z.imag[f_start:f_end])
            #plt.show()
            C_vals = -1 / (omegas[f_start:f_end] * Z.imag[f_start:f_end])
            R_vals = -Z.real[f_start:f_end]
            shunt_C_vals = (y_11_data[f_start:f_end] + y_21_data[f_start:f_end]).imag / omegas[f_start:f_end]
            cap.set_params(np.mean(C_vals), np.mean(R_vals), np.mean(shunt_C_vals), SRF)
            cap.get_deviation_from_theoretical_value()
            cap.line_length = width
            cap.line_width =  length
            processed_units.append(cap)

    return processed_units

units = process_all_plate_caps(sim_path)

#base_dir = r"C:\Users\Marci\Documents\ETH\Spring 2025\Bachelor Thesis\Lab Measurements\2025-05-22_S-Para-Measurements"
#plate_capacitor_ids = [i for i in range(36, 56)]
#plate_capacitor_batch = Batch(plate_capacitor_ids, base_dir, "Plate_Capacitors")
#plate_capacitor_batch.process_units()

# Capacitance values deviation from expected values
x = units[0].lengths

y = units[0].widths
print(x,y)
# Prepare data containers
sim_cap = {}
sim_resistance = {}
sim_inductance = {}
sim_shunt = {}
SRF = {}
for unit in units:
    key = (unit.line_length,unit.line_width)
    sim_cap[key] = unit.series_capacitance * 1e12  # pF
    SRF[key]  = unit.SRF
    sim_resistance[key] = unit.series_resistance
    sim_inductance[key] = unit.L
    sim_shunt[key] = unit.shunt_capacitance

# Generate 1 dataset
CAP_sim = fill_data(sim_cap, x, y)   # Scale by 0.7 *0.8
SRF_data = fill_data(SRF, x, y)
resistance_data = fill_data(sim_resistance, x, y)
inductance_data = fill_data(sim_inductance, x, y)
shunt_data = fill_data(sim_shunt, x, y)



"""
# Prepare data containers
measured_cap = {}
for unit in plate_capacitor_batch.processed_units:
    key = (unit.line_length, unit.line_width)
    measured_cap[key] = unit.series_capacitance * 1e12  # pF

# Generate 1 dataset
CAP_meas = fill_data(measured_cap, x, y)


# Avoid division by zero
with np.errstate(divide='ignore', invalid='ignore'):
    deviation = 100 * np.abs(CAP_meas - CAP_sim) / CAP_sim
    deviation = np.nan_to_num(deviation)  # replace NaNs with 0 if any

fig, ax = plt.subplots(figsize=(7, 6))
im = ax.imshow(deviation, cmap='coolwarm', origin='lower')

# Set ticks and labels
ax.set_xticks(range(len(x)))
ax.set_xticklabels(x, rotation=45)
ax.set_yticks(range(len(y)))
ax.set_yticklabels(y)

# Axis labels and title
ax.set_xlabel("Plate Lengths [µm]")
ax.set_ylabel("Plate Widths [µm]")
ax.set_title("Percentage Deviation Between Measured and Simulated Capacitance")

# Annotate values
for i in range(len(y)):
    for j in range(len(x)):
        ax.text(j, i, f"{deviation[i, j]:.1f}%", ha="center", va="center", color="white", fontsize=8)

# Colorbar
cbar = plt.colorbar(im)
cbar.set_label("Deviation [%]")

plt.tight_layout()
plt.show()

fig, axs = plt.subplots(1, 2, figsize=(14, 6))

titles = ["Measured Capacitance [pF]", "Simulated Capacitance [pF]"]
datasets = [CAP_meas, CAP_sim]
cmaps = ['viridis', 'plasma']

for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
    im = ax.imshow(data, cmap=cmap, origin='lower')

    # Set ticks and labels
    ax.set_xticks(range(len(x)))
    ax.set_xticklabels(x, rotation=45)
    ax.set_yticks(range(len(y)))
    ax.set_yticklabels(y)

    # Axis labels
    ax.set_xlabel("Plate Length [µm]")
    ax.set_ylabel("Plate Width [µm]")
    ax.set_title(title)

    # Annotate values in each cell
    for i in range(len(y)):
        for j in range(len(x)):
            ax.text(j, i, f"{data[i, j]:.2f}", ha="center", va="center", color="white", fontsize=8)

    # Colorbar for each subplot
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label("Capacitance [pF]")

plt.tight_layout()
plt.show()
"""
# Data to plot
datasets = [
    (CAP_sim, "Simulated Capacitance [pF]", "plasma", "Cap [pF]"),
    (resistance_data, "Series Resistance [Ω]", "magma", "Resistance [Ω]"),
    (shunt_data, "Shunt Capacitance [fF]", "cividis", "Cap [fF]")
]

# Plot
fig, axs = plt.subplots(1, len(datasets), figsize=(5 * len(datasets), 6))

for ax, (data, title, cmap, cbar_label) in zip(axs, datasets):
    im = ax.imshow(data, cmap=cmap, origin='lower')

    # Tick settings
    ax.set_xticks(range(len(x)))
    ax.set_xticklabels(x, rotation=45)
    ax.set_yticks(range(len(y)))
    ax.set_yticklabels(y)

    # Labels and title
    ax.set_xlabel("Plate Length [µm]")
    ax.set_ylabel("Plate Width [µm]")
    ax.set_title(title)

    # Annotations
    for i in range(len(y)):
        for j in range(len(x)):
            ax.text(j, i, f"{data[i, j]:.2f}", ha="center", va="center", color="white", fontsize=8)

    # Colorbar
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label(cbar_label)

plt.tight_layout()
plt.show()
