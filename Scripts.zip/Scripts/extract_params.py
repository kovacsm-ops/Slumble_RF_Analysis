import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import find_peaks



# Load data
#data_path = r"D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\n_sweep_40_2_2\S_param_n_sweep.csv"
# "D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\trace_sweep_3_40_6\S_params_trace_sweep_3_40_6.csv"
# "D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\n_sweep_40_2_2\S_param_n_sweep.csv"
# "D:\Studenten\Kovacs_Marton\privat\Inductor Design\Sweep_results\gap_sweep_3_40_2\S_params_gap_sweep_3_40_2.csv"
# Sweep params
# n, gap_size, thickness

#df = pd.read_csv(data_path)


def par(a,b):
    return (a*b)/(a+b)

def series_impedance(w,L,R,C):
    Z_C = 1/(w*1j*C)
    Z_L = (w * 1j * L)
    return par((Z_L+R), Z_C)

def shunt_impedance(w,C_ox,C_sub,G):
    Z_C = 1 / (w * 1j * C_ox)

def s_to_y(S11, S21, Z0=50):
    S = np.array([
        [S11, S21],
        [S21, S11]
    ], dtype=complex)
    I = np.identity(2, dtype=complex)
    Y = (1 / Z0) * np.matmul(I - S, np.linalg.inv(I + S))
    return Y[0][0], Y[0][1]

def y_to_z(Y_11,Y_21):
    Y = np.array([
        [Y_11, Y_21],
        [Y_21, Y_11]
    ], dtype=complex)

    Z = np.linalg.inv(Y)
    return Z[0][0], Z[0][1]

def fit_params(full_data_set):
    sweep_param = "n"
    sweep_params = full_data_set[sweep_param].unique()
    for param in sweep_params:
        frequencies = (full_data_set['freq'] * 1e9).to_numpy()
        S_11_data = full_data_set["S11"].str.replace('i', 'j').astype(complex).to_numpy()
        S_21_data = full_data_set["S21"].str.replace('i', 'j').astype(complex).to_numpy()
        S_11_data = S_11_data[full_data_set[sweep_param] == param]
        S_21_data = S_21_data[full_data_set[sweep_param] == param]

        y_11_data = []
        y_21_data = []
        for index, s_param in enumerate(S_11_data):
            y_11, y_21 = s_to_y(S_11_data[index], S_21_data[index])
            y_11_data.append(y_11)
            y_21_data.append(y_21)
        frequencies_filtered = frequencies[full_data_set[sweep_param] == param]
        y_11_data = np.array(y_11_data)
        y_21_data = np.array(y_21_data)
        Z_series = -1/y_21_data
        y_shunt = y_11_data + y_21_data
        real_parts = Z_series.real
        imag_parts = Z_series.imag
        omegas = 2*np.pi*frequencies_filtered

        # Find self resonance frequency (SRF)
        peaks, _ = find_peaks(abs(Z_series.imag))
        f_0 = (frequencies_filtered[peaks[0]] + frequencies_filtered[peaks[0] + 1])/2
        omega_0 = 2*np.pi*f_0

        # Find Series parameters
        M = construct_M_matrix(3,2,omegas, real_parts,imag_parts)
        C =construct_C_vector(3,2,omegas,real_parts, imag_parts)
        N =np.linalg.inv(M) @ C
        L = N[1]
        R = N[0]
        C = 1/(N[1]*omega_0**2)
        print(f"R: {N[0]}, L: {N[1]}, C: {1/(N[1]*omega_0**2)}")

        # Find Shunt parameters
        # Find Series parameters
        real_parts = y_shunt.real
        imag_parts = y_shunt.imag
        M = construct_M_matrix(3, 1, omegas, real_parts, imag_parts)
        C = construct_C_vector(3, 1, omegas, real_parts, imag_parts)
        N = np.linalg.inv(M) @ C
        print(N)


def lambda_h(h, omegas):
    return sum([omega**h for omega in omegas])

def S_h(h, omegas, real_parts):
    return sum([real_parts[i]*omegas[i]**h for i in range(len(omegas))])

def T_h(h, omegas, imag_parts):
    return sum([imag_parts[i]*omegas[i]**h for i in range(len(omegas))])

def U_h(h, omegas, real_parts,imag_parts):
    return sum([(real_parts[i]**2 + imag_parts[i]**2)*omegas[i]**h for i in range(len(omegas))])

def construct_C_vector(A_size,B_size, omegas, real_parts,imag_parts):
    c = np.zeros(A_size+B_size)
    for i in range(A_size):
        if i % 2 == 0:
            c[i] = S_h(i,omegas, real_parts)
        else:
            c[i] = T_h(i, omegas, imag_parts)
    for j in range(B_size):
        if j % 2 == 0:
            c[A_size+j] = 0
        else:
            c[A_size+j] =  U_h(j+1, omegas, real_parts, imag_parts)

    return c

def construct_M_matrix(A_length,B_length, omegas,real_parts, imag_parts):
    size = A_length + B_length
    A = construct_top_left(A_length,B_length, omegas)
    B = construct_top_right(A_length,B_length, omegas,real_parts, imag_parts)
    C = construct_bottom_left(A_length,B_length, omegas,real_parts, imag_parts)
    D = construct_bottom_right(A_length,B_length, omegas,real_parts, imag_parts)

    top = np.hstack((A,B))
    bottom = np.hstack((C,D))
    M = np.vstack((top,bottom))
    return M

def construct_top_left(A_size,B_size, omegas):
    M = np.zeros((A_size, A_size))
    for i in range(A_size):
        # Row index
        for j in range(A_size):
            if i % 2 == 0:
                if j % 2 == 0:
                    if i == j:
                        M[i][j] = ((-1) ** (j / 2)) * lambda_h(j * 2, omegas)
                    else:
                        M[i][j] = ((-1) ** (j / 2)) * lambda_h(find_diag(i, j) * 2, omegas)
                else:
                    M[i][j] = 0
            else:
                if j % 2 != 0:
                    if i == j:
                        M[i][j] = ((-1) ** ((j - 1) / 2)) * lambda_h(j * 2, omegas)
                    else:
                        M[i][j] = ((-1) ** ((j - 1) / 2)) * lambda_h(find_diag(i, j) * 2, omegas)
                else:
                    M[i][j] = 0
    return M

def construct_top_right(A_size,B_size, omegas, real_p, imag_p):
    M = np.zeros((A_size, B_size))
    for i in range(A_size):
        # Row index
        for j in range(B_size):
            if i == 0:
                val = j + 1
                if j % 4 == 0 or j % 4 == 1:
                    if (i+j) % 2 == 0:
                        M[i][j] = T_h(val,omegas,imag_p)
                    else:
                        M[i][j] = S_h(val, omegas,real_p)
                else:
                    if (i + j) % 2 == 0:
                        M[i][j] = -T_h(val, omegas, imag_p)
                    else:
                        M[i][j] = -S_h(val, omegas, real_p)
            else:
                val = i + j + 1
                if i % 2 == 0:
                    if j % 4 == 0 or j % 4 == 1:
                        if (i + j) % 2 == 0:
                            M[i][j] = T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = S_h(val, omegas, real_p)
                    else:
                        if (i + j) % 2 == 0:
                            M[i][j] = -T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = -S_h(val, omegas, real_p)
                else:
                    if j % 4 == 1 or j % 4 == 2:
                        if (i + j) % 2 == 0:
                            M[i][j] = T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = S_h(val, omegas, real_p)
                    else:
                        if (i + j) % 2 == 0:
                            M[i][j] = -T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = -S_h(val, omegas, real_p)
    return M

def construct_bottom_left(A_size,B_size, omegas, real_p, imag_p):
    M = np.zeros((B_size, A_size))
    for i in range(B_size):
        # Row index
        for j in range(A_size):
            if i == 0:
                val = j + 1
                if j % 4 == 0 or j % 4 == 3:
                    if (i + j) % 2 == 0:
                        M[i][j] = T_h(val, omegas, imag_p)
                    else:
                        M[i][j] = S_h(val, omegas, real_p)
                else:
                    if (i + j) % 2 == 0:
                        M[i][j] = -T_h(val, omegas, imag_p)
                    else:
                        M[i][j] = -S_h(val, omegas, real_p)
            else:
                val = i + j + 1
                if i % 2 == 0:
                    if j % 4 == 0 or j % 4 == 3:
                        if (i + j) % 2 == 0:
                            M[i][j] = T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = S_h(val, omegas, real_p)
                    else:
                        if (i + j) % 2 == 0:
                            M[i][j] = -T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = -S_h(val, omegas, real_p)
                else:
                    if j % 4 == 0 or j % 4 == 1:
                        if (i + j) % 2 == 0:
                            M[i][j] = T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = S_h(val, omegas, real_p)
                    else:
                        if (i + j) % 2 == 0:
                            M[i][j] = -T_h(val, omegas, imag_p)
                        else:
                            M[i][j] = -S_h(val, omegas, real_p)
    return M

def construct_bottom_right(A_size,B_size, omegas, real_p, imag_p):
    M = np.zeros((B_size, B_size))
    for i in range(B_size):
        # Row index
        for j in range(B_size):
            if i % 2 == 0:
                if j % 2 == 0:
                    if i == j:
                        M[i][j] = ((-1) ** (j / 2)) * U_h((j+1) * 2, omegas,real_p,imag_p)
                    else:
                        M[i][j] = ((-1) ** (j / 2)) * U_h((find_diag(i, j) + 1) * 2, omegas,real_p,imag_p)
                else:
                    M[i][j] = 0
            else:
                if j % 2 != 0:
                    if i == j:
                        M[i][j] = ((-1) ** ((j - 1) / 2)) * U_h((j+1) * 2, omegas,real_p,imag_p)
                    else:
                        M[i][j] = ((-1) ** ((j - 1) / 2)) * U_h((find_diag(i, j)+1) * 2, omegas,real_p,imag_p)
                else:
                    M[i][j] = 0
    return M

def find_diag(i,j):
    if i > j: # lower part
        while i != j:
            i -= 1
            j += 1
        return i
    else:
        while i != j:
            i += 1
            j -= 1
        return i






