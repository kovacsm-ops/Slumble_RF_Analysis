"""
Processes bais tee desings, make sure to check the file format name and change it acccordingly in
file = os.path.join(base_path,f"File_{id}_2.s2p")

If different units are used than 121-131, bias tee class has to be changed accordingly.
"""
import skrf as rf
import matplotlib.pyplot as plt
import os
import numpy as np
from batches.unit import BiasTee

base_path = r"D:\Labor\MessungenStudenten\Kovacs\Reformatted_files"
ids=[502,506,510]
units = []
for id in range(96,121):
    file = os.path.join(base_path,f"File_{id}_2.s2p")
    bias_tee_nw = rf.Network(file)
    s21_mag_db = 20 * np.log10(np.abs(bias_tee_nw.s[:, 1, 0]))  # S21 in dB
    s11_mag_db = 20 * np.log10(np.abs(bias_tee_nw.s[:, 0, 0]))  # S11 in dB

    Z = 2 * 50 * (1 / bias_tee_nw.s[:,1,0] - 1)
    #Z = -1/bias_tee_nw.y[:,1,0]
    R = Z.real
    SRF = bias_tee_nw.f[np.argmax(R)]
    L = Z.imag / (bias_tee_nw.f * 2 * np.pi)
    #print(SRF * 1e-9)
    #print(np.mean(L[100:300]))

    indices_in_band = np.where(s21_mag_db <= -3)[0]
    mean_s21_mag = np.mean(s21_mag_db[indices_in_band[0]:indices_in_band[-1]])
    mean_s11_mag = np.mean(s11_mag_db[indices_in_band[0]:indices_in_band[-1]])
    f_start = bias_tee_nw.f[indices_in_band[0]]
    f_stop = bias_tee_nw.f[indices_in_band[-1]]
    bandwidth = f_stop - f_start
    #print(f"3 dB Bandwidth: {bandwidth * 1e-9:.2f} GHz "
     #     f"(from {f_start * 1e-9:.2f} GHz to {f_stop * 1e-9:.2f} GHz)")
    bt = BiasTee(id)
    bt.set_data(bandwidth,mean_s21_mag,mean_s11_mag)
    bias_tee_nw.name = f"Turns_{bt.nr_of_turns}_Width_{bt.cap_width}"
    units.append(bt)
    print(bt.id, bt.nr_of_turns, bt.cap_width)


# Function to fill data from dictionary
def fill_data(data_dict, x, y):
    data = np.zeros((len(y), len(x)))
    for i, x_unit in enumerate(x):
        for j, y_unit in enumerate(y):
            key = (x_unit, y_unit)
            try:
                data[j][i] = data_dict.get(key, 0)
            except Exception as e:
                data[j][i] = 0
    return np.round(data, 4)



# Assuming x, y are defined as:
x = units[0].widths
y = units[0].number_of_turns_array

# Prepare data containers
bw_dict = {}
avg_insertion_loss_dict = {}
avg_return_loss_dict = {}


for unit in units:
    key = (unit.cap_width,unit.nr_of_turns)
    bw_dict[key] = unit.bandwidth *1e-9
    avg_insertion_loss_dict[key] = unit.avg_insertion_loss
    avg_return_loss_dict[key] = unit.avg_return_loss

# Generate 3 datasets
bw_data = fill_data(bw_dict, x, y)
avg_insertion_loss_data = fill_data(avg_insertion_loss_dict, x, y)
avg_return_loss_data = fill_data(avg_return_loss_dict, x, y)


# Create 1-row, 3-column plot
fig, axs = plt.subplots(1, 3, figsize=(18, 6))
titles = ["Bandwidth [GHz]", "Average S21 in pass Band [dB]", "Average S11 in pass Band [dB]"]
datasets = [bw_data, avg_insertion_loss_data, avg_return_loss_data]
cmaps = ['coolwarm', 'viridis','plasma']

for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
    im = ax.imshow(data, cmap=cmap, origin='lower')
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(title)

    # Ticks
    ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
    ax.set_yticks(range(len(y)), labels=y)

    # Labels
    ax.set_xlabel("Capacitor Width [µm]")
    ax.set_ylabel("Inductor Spiral Turns")

    # Annotate each cell
    for i in range(len(x)):
        for j in range(len(y)):
            ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

    ax.set_title(title)

fig.suptitle("Bias Tee Designs", fontsize=16)
fig.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()



file = os.path.join(base_path,f"File_120_0.s2p")
bias_tee_nw = rf.Network(file)
s21_mag_db = 20 * np.log10(np.abs(bias_tee_nw.s[:, 1, 0]))  # S21 in dB
s11_mag_db = 20 * np.log10(np.abs(bias_tee_nw.s[:, 0, 0]))  # S11 in dB

freq_ghz = bias_tee_nw.frequency.f / 1e9                # frequency axis in GHz


# Phase in degrees
s21_phase_deg = np.angle(bias_tee_nw.s[:, 1, 0], deg=True)
s11_phase_deg = np.angle(bias_tee_nw.s[:, 0, 0], deg=True)

# --- Plot magnitude (top) and phase (bottom) ---------------------------------
fig, (ax_mag, ax_phase) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Magnitude plot
ax_mag.plot(freq_ghz, s21_mag_db, label="|S21| (dB)")
#ax_mag.plot(freq_ghz, s11_mag_db, label="|S11| (dB)")
ax_mag.set_ylabel("Magnitude (dB)")
ax_mag.set_title("S-parameters Magnitude")
ax_mag.grid(True)
ax_mag.legend()

# Phase plot
ax_phase.plot(freq_ghz, s21_phase_deg, label="∠S21 (°)")
ax_phase.set_xlabel("Frequency (GHz)")
ax_phase.set_ylabel("Phase (°)")
ax_phase.set_title("S-parameters Phase")
ax_phase.grid(True)
ax_phase.legend()

plt.tight_layout()
plt.show()


