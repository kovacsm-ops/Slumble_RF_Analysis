import skrf as rf
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt

bias_tee_path = r"D:\Labor\MessungenStudenten\Kovacs\Touchstone_Files\CpwBiasTee_512_ID1299_SParameter_2025-06-04_151328.s2p"

bias_tee_nw = rf.Network(bias_tee_path)

# Plotting raw S params
plt.figure(figsize=(10, 10))
plt.suptitle('Raw measurements')
plt.subplot(2, 2, 1)
bias_tee_nw.plot_s_db(0, 0)
bias_tee_nw.plot_s_db(1, 1)

plt.subplot(2, 2, 2)
bias_tee_nw.plot_s_deg(0, 0)
bias_tee_nw.plot_s_deg(1, 1)

plt.subplot(2, 2, 3)
bias_tee_nw.plot_s_db(1, 0)
bias_tee_nw.plot_s_db(0, 1)

plt.subplot(2, 2, 4)
bias_tee_nw.plot_s_deg(1, 0)
bias_tee_nw.plot_s_deg(0, 1)
plt.show()