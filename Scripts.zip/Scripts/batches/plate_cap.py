import skrf as rf
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt

base = r"C:\Users\Marci\Documents\ETH\Spring 2025\Bachelor Thesis\Lab Measurements\2025-05-22_S-Para-Measurements"
gsg_1 = os.path.join(base, f"File_{55}.s2p")
gsg_2 = os.path.join(base, f"File_{45}.s2p")

GSG250 = rf.Network(gsg_1)
GSG250.name = "55"
GSG500 = rf.Network(gsg_2)
GSG500.name = "45"

# Plotting raw S params
plt.figure(figsize=(10, 10))
plt.suptitle('Raw measurements')
plt.subplot(2, 2, 1)
GSG250.plot_s_db(0, 0)
GSG500.plot_s_db(0, 0)
GSG250.plot_s_db(1, 1)
GSG500.plot_s_db(1, 1)

plt.subplot(2, 2, 2)
GSG250.plot_s_deg(0, 0)
GSG500.plot_s_deg(0, 0)
GSG250.plot_s_deg(1, 1)
GSG500.plot_s_deg(1, 1)
plt.subplot(2, 2, 3)
GSG250.plot_s_db(1, 0)
GSG500.plot_s_db(1, 0)
GSG250.plot_s_db(0, 1)
GSG500.plot_s_db(0, 1)
plt.subplot(2, 2, 4)
GSG250.plot_s_deg(1, 0)
GSG500.plot_s_deg(1, 0)
GSG250.plot_s_deg(0, 1)
GSG500.plot_s_deg(0, 1)

plt.show()
