import numpy as np

class Unit:
    def __init__(self, id):
        self.id = id

# Waveguides
class GSG(Unit):
    def __init__(self, id):
        super().__init__(id)
        length = 2

class BiasTee(Unit):
    def __init__(self, id):
        super().__init__(id)
        self.number_of_turns_array = [1, 2, 3, 4, 5]
        self.widths = [10,20, 30, 40, 50]
        #self.widths = [20,40]
        self.set_geom()
        self.bandwidth = None
        self.avg_insertion_loss = None
        self.avg_return_loss = None

    def set_data(self, bw, insertion_loss, return_loss):
        self.bandwidth = bw
        self.avg_insertion_loss = insertion_loss
        self.avg_return_loss = return_loss

    def set_geom(self):
        self.cap_width = self.widths[(self.id - 121)//len(self.widths) ]
        self.nr_of_turns = self.number_of_turns_array[(self.id - 121) % len(self.widths)]
# Inductors
class Inductor(Unit):
    def __init__(self, id):
        super().__init__(id)
        # Series params
        self.series_inductance = None
        self.series_resistance = None
        self.series_capacitance = None

        # Shunt params
        self.shunt_capacitance = None

        # MEAN VALUES above 2 Ghz
        self.series_inductance_mean = None
        self.series_resistance_mean = None
        self.series_capacitance_mean = None

        # Shunt params
        self.shunt_capacitance_mean = None


    def set_params(self, ser_induct, ser_res, shunt_cap, SRF=None):
        self.series_inductance = ser_induct
        self.series_resistance = ser_res
        self.shunt_capacitance = shunt_cap

        # MEAN VALUES
        self.series_inductance_mean = np.mean(ser_induct)
        self.series_resistance_mean = np.mean(ser_res)

        self.shunt_capacitance_mean = np.mean(shunt_cap[100:300])
        if SRF is not None:
            self.SRF = SRF
            self.par_cap = 1/(self.series_inductance_mean*(2*np.pi*SRF)**2)
        print(f"Unit: {self.id}, Inductance: {self.series_inductance_mean * 1e9},Resistance {self.series_resistance_mean}, Substrate_Cap { self.shunt_capacitance_mean * 1e15}, SRF {self.SRF * 1e-9}, par cap {self.par_cap * 1e15}")

    def set_params_fit(self, ser_induct, ser_res, shunt_cap):
        self.shunt_capacitance = shunt_cap

        # MEAN VALUES
        self.series_inductance_mean = ser_induct
        self.series_resistance_mean = ser_res



    def arc_length(self, theta, a, b):
        r = a + b * theta
        return (np.sqrt(r ** 2 + b ** 2) * r / (2 * b) + 0.5 * b * np.arctan(r / np.sqrt(r ** 2 + b ** 2)))

    def L(self, theta_0, theta_1, a, b):
        return self.arc_length(theta_1, a, b) - self.arc_length(theta_0, a, b)

    def resistance_of_inductor(self, length, width, height):
        return 2.44e-8 * length / (width * height)


class Spiral_Inductor(Inductor):
    def __init__(self, id):
        super().__init__(id)
        self.widths = [0.5, 1, 2, 4, 6]
        self.number_of_turns_array = [1,2,3,4]
        # Geometric params
        self.nr_turns, self.trace_width  = self.get_geometric_params()
        self.expected_resistance()

    def get_geometric_params(self):
        return (self.id-16)//5 + 1, self.widths[(self.id-16) % 5]

    def expected_resistance(self):
        adjustment_length = (75 + self.nr_turns*5)*1e-6
        a = 20e-6  # Initial Radius
        b = (6e-6 + self.trace_width*1e-6)/(2*np.pi)
        spiral_length = self.L(0,self.nr_turns*2*np.pi, a, b)
        self.exp_resistance = self.resistance_of_inductor(spiral_length + adjustment_length,self.trace_width * 1e-6,0.065e-6)


class Line_Inductor(Inductor):
    def __init__(self, id):
        super().__init__(id)
        # Geometric params
        self.widths = [1,3,5,7]
        self.lengths = [100,200,300,400]
        self.line_width, self.line_length = self.get_geometric_params()
        self.height = None

    def get_geometric_params(self):
        return self.widths[self.id // 4], self.lengths[self.id % 4 ]

    def get_height(self):
        self.height = 2.44e-8 * self.line_length / (self.series_resistance_mean * self.line_width)
        return self.height

# Capacitors
class Capacitor(Unit):
    def __init__(self, id):
        super().__init__(id)
        # Series params
        self.series_resistance = None
        self.series_capacitance = None

        # Shunt params
        self.shunt_capacitance = None

        # MEAN VALUES above 2 Ghz
        self.series_resistance_mean = None
        self.series_capacitance_mean = None

        # Shunt params
        self.shunt_capacitance_mean = None

    def set_params(self, ser_cap, ser_res, shunt_cap, SRF = 0):
        self.series_capacitance = ser_cap
        self.series_resistance = ser_res
        self.shunt_capacitance = shunt_cap *1e15
        self.SRF = SRF
        if SRF != 0:
            self.L =  1/(self.series_capacitance*(self.SRF*2*np.pi)**2 )
        else:
            self.L = 0
        print(f"Unit: {self.id}, Cap: {self.series_capacitance*1e12}")
        print(f"Resistance {self.series_resistance}, Substrate_Cap {self.shunt_capacitance}, SRF {self.SRF *1e-9}, L {self.L }")


class Plate_Capacitor(Capacitor):
    def __init__(self, id):
        super().__init__(id)
        self.dev = None
        self.theoretical_value = None
        # Geometric params
        self.widths = [10, 20, 30, 40, 50]
        self.lengths = [10, 20, 30, 40]
        self.line_width, self.line_length = self.get_geometric_params()
        print(f"ID: {self.id}, Width: {self.line_width}, Length: {self.line_length}")
        self.height = None

    def get_geometric_params(self):
        return self.widths[(self.id-36) // 4], self.lengths[(self.id-36) % 4 ]

    def get_height(self):
        self.height = 8.8542e-12*9.8*(self.line_width * self.line_length)*1e-12/ self.series_capacitance
        return self.height
    def get_deviation_from_theoretical_value(self):
        e_r = 9.8
        e_0 = 8.8542e-12
        d = 170e-9
        self.theoretical_value = e_r*e_0 * (self.line_width*self.line_length) * 1e-12/d
        print(self.theoretical_value,self.series_capacitance)
        self.dev = 100*np.abs(self.theoretical_value-self.series_capacitance)/self.series_capacitance