import os
import numpy as np
import skrf as rf
from skrf.calibration import IEEEP370_SE_ZC_2xThru
import pandas as pd
import matplotlib.pyplot as plt
from extract_params import *
from batches.unit import *

class Batch:
    def __init__(self, unit_ids, base_folder_path, name="Default"):
        self.unit_ids = unit_ids
        self.base_folder_path = base_folder_path
        self.name = name

        self.processed_units = []  # Store unit instances for data processing
        self.faulty_unit_ids = [25]  # Store unprocessable unit ids
        self.through = r"D:\Studenten\Kovacs_Marton\oeffentlich\67GHz measurements\touchstone\THROUGH_ID371_SParameter_2025-06-02_215038.s2p"
        self.through_nw = rf.Network(self.through)

    def extract_impedance(self,network):
        # Extract frequency in Hz
        freqs = network.f  # frequency in Hz
        # Get S-parameter matrix: shape = (n_freqs, n_ports, n_ports)
        s_params = network.s
        z_matrix = network.z
        y_matrix = network.y

        # Convert to DataFrame
        data = []
        for i, freq in enumerate(freqs):
            s11 = s_params[i, 0, 0]
            s21 = s_params[i, 1, 0]
            s12 = s_params[i, 0, 1]
            s22 = s_params[i, 1, 1]
            Z11 = z_matrix[i, 0, 0]
            Z21 = z_matrix[i, 1, 0]
            Y11 = y_matrix[i, 0, 0]
            Y21 = y_matrix[i, 1, 0]
            data.append({
                "frequency_Hz": freq,
                "S11_dB": 20 * np.log10(abs(s11)),
                "S21_dB": 20 * np.log10(abs(s21)),
                "S12_dB": 20 * np.log10(abs(s12)),
                "S22_dB": 20 * np.log10(abs(s22)),
                "S11": s11,
                "S21": s21,
                "S12": s12,
                "S22": s22,
                "S11_phase_deg": np.angle(s11, deg=True),
                "S21_phase_deg": np.angle(s21, deg=True),
                "S12_phase_deg": np.angle(s12, deg=True),
                "S22_phase_deg": np.angle(s22, deg=True),
                "Z11": Z11,
                "Z21": Z21,
                "Y11": Y11,
                "Y21": Y21
            })

        df = pd.DataFrame(data)
        return df

    def db_mag_and_phase_to_complex(self,db_mag, phase_deg):
        linear_mag = 10 ** (db_mag / 20)
        return linear_mag * np.exp(1j * np.deg2rad(phase_deg))

    def process_units(self):
        for id in self.unit_ids:
            if id in self.faulty_unit_ids:
                pass
            else:

                filename = os.path.join(self.base_folder_path, f"File_{id}_0.s2p")
                try:
                    if self.name == "Spiral_Inductor":
                        self.process_spiral_inductor(filename, id)
                    elif self.name == "Line_Inductors":
                        self.process_line_inductor(filename, id)
                    else:
                        self.process_plate_capacitor(filename, id)
                except Exception as faultyUnit:
                    try:
                        filename = os.path.join(self.base_folder_path, f"File_{id}.s2p")
                        if self.name == "Spiral_Inductor":
                            self.process_spiral_inductor(filename, id)
                        elif self.name == "Line_Inductors":
                            self.process_line_inductor(filename, id)
                        else:
                            self.process_plate_capacitor(filename, id)
                    except Exception as e:
                        if id not in self.faulty_unit_ids:
                            self.faulty_unit_ids.append(id)
                        print(f"Failed to process unit: {id}")
                        print(f"Error: {faultyUnit}")
        print(f"Processed {len(self.processed_units)} units")


    def process_spiral_inductor(self,file_path,id, deembed = False):

        if deembed:
            s2xthru = rf.Network(self.through)
            fdf_ntw = rf.Network(file_path)

            # Define a common uniform frequency grid across both networks
            f_min = max(s2xthru.f[0], fdf_ntw.f[0])
            f_max = min(s2xthru.f[-1], fdf_ntw.f[-1])
            n_points = 501
            uniform_freqs = np.linspace(f_min, f_max, n_points)

            # Interpolate both to the same uniform frequency grid
            s2xthru = s2xthru.interpolate(uniform_freqs)
            fdf_ntw = fdf_ntw.interpolate(uniform_freqs)

            # De-embedding using interpolated networks
            dm = IEEEP370_SE_ZC_2xThru(
                dummy_2xthru=s2xthru,
                dummy_fix_dut_fix=fdf_ntw,
                pullback1=0,
                pullback2=0,
                leadin=0,
                name='zc2xthru'
            )

            print("Deembedding...")
            ntw = dm.deembed(fdf_ntw)
            df = self.extract_impedance(ntw)
            S_21_data = np.array(df["S21"])
            Y_11_data = np.array(df["Y11"])
            Y_21_data = np.array(df["Y21"])
            frequencies = np.array(df["frequency_Hz"])
            omegas = np.array(2 * np.pi * frequencies)

            start_index = 0
            S_21_cut = S_21_data[start_index:]
            Y_11_cut = Y_11_data[start_index:]
            Y_21_cut = Y_21_data[start_index:]
            omegas_cut = omegas[start_index:]
            frequencies_cut = frequencies[start_index:]

            print(f"Start Frequency: {frequencies[start_index] * 1e-9} GHz")
            # Under the assumption that the measured frequency range is far from SRF
            Z = 2 * 50 * (1 / S_21_cut - 1)
            L = Z.imag / omegas_cut
            R = (-1 / Y_21_cut).real
            shunt_C = (Y_11_cut + Y_21_cut).imag / omegas_cut
            ind = Spiral_Inductor(id)
            ind.set_params(L, R, shunt_C)
            self.processed_units.append(ind)
        else:
            # Create network
            ntw = rf.Network(file_path)
            df = self.extract_impedance(ntw)
            S_21_data = np.array(df["S21"])
            S_21_data_db = np.array(df["S21_dB"])
            Y_11_data = np.array(df["Y11"])
            Y_21_data = np.array(df["Y21"])
            frequencies = np.array(df["frequency_Hz"])
            omegas = np.array(2 * np.pi * frequencies)

            entire_Z =  2 * 50 * (1 / S_21_data - 1)
            entire_L = entire_Z.imag / omegas


            start_index = 40 # 120 for large meas
            S_21_cut = S_21_data[start_index:]
            Y_11_cut = Y_11_data[start_index:]
            Y_21_cut = Y_21_data[start_index:]
            omegas_cut = omegas[start_index:]
            frequencies_cut = frequencies[start_index:]
            end_freq = np.argmax((-1 / Y_21_cut).imag)

            S_21_cut = S_21_data[start_index:end_freq]
            Y_11_cut = Y_11_data[start_index:end_freq]
            Y_21_cut = Y_21_data[start_index:end_freq]
            omegas_cut = omegas[start_index:end_freq]
            frequencies_cut = frequencies[start_index:end_freq]
            #print(f"Start Frequency: {frequencies[start_index] * 1e-9} GHz,"
                 # f"Stop Frequency: {frequencies[end_freq] * 1e-9} GHz")

            # Under the assumption that the measured frequency range is far from SRF
            Z = 2 * 50 * (1 / S_21_cut - 1)
            L = Z.imag / omegas_cut
            R = (-1/Y_21_cut).real
            shunt_C = (Y_11_cut + Y_21_cut).imag / omegas_cut
            ind = Spiral_Inductor(id)
            ind.set_params(L,R,shunt_C, SRF=frequencies[end_freq])
            self.processed_units.append(ind)

    def process_line_inductor(self,file_path,id):
        df = self.read_s2p(file_path)
        S_21_data = np.array(df["S21"])
        Y_11_data = np.array(df["Y11"])
        Y_21_data = np.array(df["Y21"])
        omegas = np.array(2 * np.pi * df["frequency_Hz"])

        """
        Z_series = -1 / Y_21_data
        L = Z_series.imag / omegas
        R = Z_series.real

        shunt_C = (Y_11_data + Y_21_data).imag / omegas
        shunt_R = (1 / (Y_11_data + Y_21_data).real)
        """
        Z = 2 * 50 * (1 / S_21_data - 1)
        L = Z.imag / omegas
        R = 2 * 50 * (S_21_data.real / np.abs(S_21_data) ** 2 - 1)
        shunt_C = (Y_11_data + Y_21_data).imag / omegas
        ind = Line_Inductor(id)
        ind.set_params(L, R, shunt_C)
        self.processed_units.append(ind)

    def process_plate_capacitor(self, file_path, id):
        df = self.read_s2p(file_path)
        S_21_data = np.array(df["S21"])
        Y_11_data = np.array(df["Y11"])
        Y_21_data = np.array(df["Y21"])
        omegas = np.array(2 * np.pi * df["frequency_Hz"])

        Z = (-1 / (Y_21_data))
        indeces = np.array(np.where(Z.imag>=0))
        #C = -1/((Z_series.imag) * omegas)
        # Under the assumption that the resonant frequency is much bigger than the measured range
        #Z = 2*50*(1/S_21_data-1)
        freq = df["frequency_Hz"]
        if len(indeces[0]) != 0:
            SRF = freq[indeces[0][0]]
        else:
            SRF = 0

        #plt.plot(freq[100:]*1e-9,Z[100:].imag, label=f"ID: {id}")
        #plt.legend()
        #plt.show()
        C = -1/(omegas[100:200]*Z.imag[100:200])
        R = Z.real
        shunt_C = (Y_11_data + Y_21_data).imag / omegas
        C = np.mean(C)
        R = np.mean(R)
        shunt_C = np.mean(shunt_C)
        cap = Plate_Capacitor(id)
        cap.set_params(C, R, shunt_C, SRF)
        cap.get_deviation_from_theoretical_value()
        self.processed_units.append(cap)


    def plot_batch(self):
        # Function to fill data from dictionary
        def fill_data(data_dict,x,y):
            data = np.zeros((len(y), len(x)))
            for i, x_unit in enumerate(x):
                for j, y_unit in enumerate(y):
                    key = (x_unit,y_unit)
                    try:
                        data[j][i] = data_dict.get(key, 0)
                    except Exception as e:
                        data[j][i] = 0
            return np.round(data, 4)

        if self.name == "Spiral_Inductor":

            # Assuming x, y are defined as:
            x = self.processed_units[0].widths
            y = self.processed_units[0].number_of_turns_array

            # Prepare data containers
            inductance_dict = {}
            resistance_dict = {}
            capacitance_dict = {}
            srf = []
            for unit in self.processed_units:
                key = (unit.trace_width, unit.nr_turns)
                inductance_dict[key] = unit.series_inductance_mean * 1e9  # H -> nH
                resistance_dict[key] = unit.series_resistance_mean  # Ohms
                capacitance_dict[key] = unit.shunt_capacitance_mean * 1e15  # F -> fF
                print(f"Self Resonant Freq: {unit.SRF*1e-9} fo unit: {unit.id}")
                if unit.trace_width == 2:
                    srf.append(unit.SRF*1e-9)
            # Generate 3 datasets
            L_data = fill_data(inductance_dict,x,y)
            R_data = fill_data(resistance_dict,x,y)
            C_data = fill_data(capacitance_dict,x,y)

            # Create 1-row, 3-column plot
            fig, axs = plt.subplots(1, 3, figsize=(18, 6))
            titles = ["Series Inductance [nH]", "Series Resistance [Ω]", "Shunt Capacitance [fF]"]
            datasets = [L_data, R_data, C_data]
            cmaps = ['coolwarm', 'viridis', 'plasma']

            for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
                im = ax.imshow(data, cmap=cmap, origin='lower')
                cbar = fig.colorbar(im, ax=ax)
                cbar.set_label(title)

                # Ticks
                ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
                ax.set_yticks(range(len(y)), labels=y)

                # Labels
                ax.set_xlabel("Spiral Trace Width [µm]")
                ax.set_ylabel("Spiral Turns")

                # Annotate each cell
                for i in range(len(x)):
                    for j in range(len(y)):
                        ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

                ax.set_title(title)

            fig.suptitle("Extracted Spiral Inductor Parameters", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()
            """
            # Assuming x, y are defined as:
            x = self.processed_units[0].widths
            y = self.processed_units[0].number_of_turns_array

            # Prepare data containers
            meas_resistance_dict = {}
            theoretical_resistance_dict = {}
            dev_dict = {}

            for unit in self.processed_units:
                key = (unit.trace_width, unit.nr_turns)
                meas_resistance_dict[key] = unit.series_resistance_mean  # Ohms
                theoretical_resistance_dict[key] = unit.exp_resistance  #
                dev_dict[key] = 100 * np.abs((unit.exp_resistance - unit.series_resistance_mean))/unit.series_resistance_mean

            # Generate 3 datasets
            meas_R_data = fill_data(meas_resistance_dict, x, y)
            theor_R_data = fill_data(theoretical_resistance_dict, x, y)
            deviation = fill_data(dev_dict, x, y)

            # Create 1-row, 3-column plot
            fig, axs = plt.subplots(1, 3, figsize=(18, 6))
            titles = ["Measured Resistance [Ω]", "Theoretical Resistance [Ω]", "Relative Deviation [%]"]
            datasets = [meas_R_data, theor_R_data, deviation]
            cmaps = ['coolwarm', 'viridis', 'plasma']

            for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
                im = ax.imshow(data, cmap=cmap, origin='lower')
                cbar = fig.colorbar(im, ax=ax)
                cbar.set_label(title)

                # Ticks
                ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
                ax.set_yticks(range(len(y)), labels=y)

                # Labels
                ax.set_xlabel("Spiral Trace Width [µm]")
                ax.set_ylabel("Spiral Turns")

                # Annotate each cell
                for i in range(len(x)):
                    for j in range(len(y)):
                        ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

                ax.set_title(title)

            fig.suptitle("Resistance Comparison", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()
            """
        elif self.name == "Line_Inductors":

            # NORMAL PLOT
            # Assuming x, y are defined as:
            x = self.processed_units[0].lengths
            y = self.processed_units[0].widths

            # Prepare data containers
            inductance_dict = {}
            resistance_dict = {}
            capacitance_dict = {}
            heights = []
            for unit in self.processed_units:
                key = (unit.line_length, unit.line_width)
                inductance_dict[key] = unit.series_inductance_mean * 1e9  # H -> nH
                resistance_dict[key] = unit.series_resistance_mean  # Ohms
                capacitance_dict[key] = unit.shunt_capacitance_mean * 1e15  # F -> fF
                heights.append(unit.get_height() * 1e9)


            # Generate 3 datasets
            L_data = fill_data(inductance_dict,x,y)
            R_data = fill_data(resistance_dict,x,y)
            C_data = fill_data(capacitance_dict,x,y)

            # Create 1-row, 3-column plot
            fig, axs = plt.subplots(1, 3, figsize=(18, 6))
            titles = ["Series Inductance [nH]", "Series Resistance [Ω]", "Shunt Capacitance [fF]"]
            datasets = [L_data, R_data, C_data]
            cmaps = ['coolwarm', 'viridis', 'plasma']

            for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
                im = ax.imshow(data, cmap=cmap, origin='lower')
                cbar = fig.colorbar(im, ax=ax)
                cbar.set_label(title)

                # Ticks
                ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
                ax.set_yticks(range(len(y)), labels=y)

                # Labels
                ax.set_xlabel("Line Lengths [µm]")
                ax.set_ylabel("Line Widths [µm]")

                # Annotate each cell
                for i in range(len(x)):
                    for j in range(len(y)):
                        ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

                ax.set_title(title)

            fig.suptitle("Extracted Line Inductor Parameters", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()

            plt.boxplot(heights)
            plt.ylabel("Line Height [nm]")
            plt.show()
        elif self.name == "Plate_Capacitors":
            """
            x = self.processed_units[0].lengths
            y = self.processed_units[0].widths

            # Prepare data containers
            inductance_dict = {}
            resistance_dict = {}
            capacitance_dict = {}

            for unit in self.processed_units:
                key = (unit.line_length, unit.line_width)
                inductance_dict[key] = unit.series_inductance_mean * 1e12  # F -> pF
                resistance_dict[key] = unit.series_resistance_mean  # Ohms
                capacitance_dict[key] = unit.shunt_capacitance_mean * 1e15  # F -> fF
            # Generate 3 datasets
            L_data = fill_data(inductance_dict, x, y)
            R_data = fill_data(resistance_dict, x, y)
            C_data = fill_data(capacitance_dict, x, y)

            # Create 1-row, 3-column plot
            fig, axs = plt.subplots(1, 3, figsize=(18, 6))
            titles = ["Series Capacitance [pF]", "Series Resistance [Ω]", "Shunt Capacitance [fF]"]
            datasets = [L_data, R_data, C_data]
            cmaps = ['coolwarm', 'viridis', 'plasma']

            for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
                im = ax.imshow(data, cmap=cmap, origin='lower')
                cbar = fig.colorbar(im, ax=ax)
                cbar.set_label(title)

                # Ticks
                ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
                ax.set_yticks(range(len(y)), labels=y)

                # Labels
                ax.set_xlabel("Plate Lengths [µm]")
                ax.set_ylabel("Plate Widths [µm]")

                # Annotate each cell
                for i in range(len(x)):
                    for j in range(len(y)):
                        ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

                ax.set_title(title)

            fig.suptitle("Extracted Plate Capacitor Parameters", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()
            """

            # Capacitance values deviation from expected values
            x = self.processed_units[0].lengths
            y = self.processed_units[0].widths

            # Prepare data containers
            measured_srf = {}
            for unit in self.processed_units:
                key = (unit.line_length, unit.line_width)
                measured_srf[key] = unit.SRF * 1e-9  # GHz

            # Generate 1 dataset
            SRF_meas = fill_data(measured_srf, x, y)

            fig, ax = plt.subplots(figsize=(6, 6))  # Only one Axes

            # Plot the heatmap
            im = ax.imshow(SRF_meas, cmap='coolwarm', origin='lower')

            # Colorbar
            cbar = fig.colorbar(im, ax=ax)
            cbar.set_label("SRF [GHz]")

            # Ticks
            ax.set_xticks(range(len(x)))
            ax.set_xticklabels(x, rotation=45, ha="right", rotation_mode="anchor")
            ax.set_yticks(range(len(y)))
            ax.set_yticklabels(y)

            # Labels
            ax.set_xlabel("Plate Lengths [µm]")
            ax.set_ylabel("Plate Widths [µm]")

            # Annotate each cell
            for i in range(len(x)):
                for j in range(len(y)):
                    ax.text(i, j, f"{SRF_meas[j, i]:.2f}", ha="center", va="center", color="w", fontsize=8)

            # Title
            ax.set_title("SRF [GHz]")
            fig.suptitle("Plate Capacitance Measured VS Theoretical", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()

            """
            # Generate 3 datasets
            SRF_meas = fill_data(measured_srf, x, y)

            fig, axs = plt.subplots(1, 1, figsize=(18, 6))
            titles = ["SRF [GHz]"]
            datasets = [SRF_meas]
            cmaps = ['coolwarm', 'viridis', 'plasma']

            for ax, data, title, cmap in zip(axs, datasets, titles, cmaps):
                im = ax.imshow(data, cmap=cmap, origin='lower')
                cbar = fig.colorbar(im, ax=ax)
                cbar.set_label(title)

                # Ticks
                ax.set_xticks(range(len(x)), labels=x, rotation=45, ha="right", rotation_mode="anchor")
                ax.set_yticks(range(len(y)), labels=y)

                # Labels
                ax.set_xlabel("Plate Lengths [µm]")
                ax.set_ylabel("Plate Widths [µm]")

                # Annotate each cell
                for i in range(len(x)):
                    for j in range(len(y)):
                        ax.text(i, j, data[j, i], ha="center", va="center", color="w", fontsize=8)

                ax.set_title(title)

            fig.suptitle("Plate Capacitance Measured VS Theoretical", fontsize=16)
            fig.tight_layout(rect=[0, 0.03, 1, 0.95])
            plt.show()
            """

    def check_s2p(self, filename):
        if not os.path.exists(filename):
            raise FileNotFoundError(f"File not found: {filename}")
        if os.path.getsize(filename) == 0:
            raise ValueError(f"File is empty: {filename}")
        if not filename.lower().endswith(".s2p"):
            raise ValueError(f"Invalid file extension (expected .s2p): {filename}")

        return rf.Network(filename)

    def read_s2p(self,filename):
        # Load the network
        network = self.check_s2p(filename)

        # Extract frequency in Hz
        freqs = network.f  # frequency in Hz

        # Get S-parameter matrix: shape = (n_freqs, n_ports, n_ports)
        s_params = network.s
        z_matrix = network.z
        y_matrix = network.y

        # Convert to DataFrame
        data = []
        for i, freq in enumerate(freqs):
            s11 = s_params[i, 0, 0]
            s21 = s_params[i, 1, 0]
            s12 = s_params[i, 0, 1]
            s22 = s_params[i, 1, 1]
            Z11 = z_matrix[i, 0, 0]
            Z21 = z_matrix[i, 1, 0]
            Y11 = y_matrix[i, 0, 0]
            Y21 = y_matrix[i, 1, 0]
            data.append({
                "frequency_Hz": freq,
                "S11_dB": 20 * np.log10(abs(s11)),
                "S21_dB": 20 * np.log10(abs(s21)),
                "S12_dB": 20 * np.log10(abs(s12)),
                "S22_dB": 20 * np.log10(abs(s22)),
                "S11": s11,
                "S21": s21,
                "S12": s12,
                "S22": s22,
                "S11_phase_deg": np.angle(s11, deg=True),
                "S21_phase_deg": np.angle(s21, deg=True),
                "S12_phase_deg": np.angle(s12, deg=True),
                "S22_phase_deg": np.angle(s22, deg=True),
                "Z11": Z11,
                "Z21": Z21,
                "Y11": Y11,
                "Y21": Y21
            })

        df = pd.DataFrame(data)
        return df

